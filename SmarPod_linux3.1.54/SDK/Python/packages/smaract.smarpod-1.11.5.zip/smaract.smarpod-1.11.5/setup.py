from setuptools import find_namespace_packages
from setuptools import setup
packageNames=find_namespace_packages(include=["smaract.smarpod"])
setup(
    name="smaract.smarpod",
    version="1.11.5",
    packages=packageNames,
    description="SmarAct SmarPod Python API",
    url="https://www.smaract.com",
    maintainer="SmarAct GmbH",
    install_requires=("cffi"),
    license="SmarAct EULA"
)
