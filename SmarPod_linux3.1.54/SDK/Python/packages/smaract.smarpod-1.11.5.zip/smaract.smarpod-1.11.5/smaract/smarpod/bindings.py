#######################################################################
# Copyright (c) 2025 SmarAct GmbH
#
# THIS  SOFTWARE, DOCUMENTS, FILES AND INFORMATION ARE PROVIDED 'AS IS'
# WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
# BUT  NOT  LIMITED  TO, THE  IMPLIED  WARRANTIES  OF MERCHANTABILITY,
# FITNESS FOR A PURPOSE, OR THE WARRANTY OF NON - INFRINGEMENT.
# THE  ENTIRE  RISK  ARISING OUT OF USE OR PERFORMANCE OF THIS SOFTWARE
# REMAINS WITH YOU.
# IN  NO  EVENT  SHALL  THE  SMARACT  GMBH  BE  LIABLE  FOR ANY DIRECT,
# INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL OR OTHER DAMAGES ARISING
# OUT OF THE USE OR INABILITY TO USE THIS SOFTWARE.
#
# Generated on 2025-06-27 10:14 +0200
#

"""
Python bindings for SmarPod
(C) SmarAct GmbH
Refer to the SmarAct EULA for licensing
SmarAct SmarPod Python API
"""

from cffi import FFI
import enum
import sys
assert sys.version_info >= (3, 4), "Python v3.4 or higher is required"
apigen_version = (1, 9, 3)
api_version = (1, 11, 5)
def __initBindings(libName):
    global ffi, lib
    ffi = FFI()
    ffi.cdef("""
typedef struct { double positionX; double positionY; double positionZ; double rotationX; double rotationY; double rotationZ;}Smarpod_Pose;
typedef unsigned int Smarpod_Status;
Smarpod_Status Smarpod_GetDLLVersion(unsigned int *major, unsigned int *minor, unsigned int *update);
Smarpod_Status Smarpod_GetStatusInfo(Smarpod_Status status, char const **statusInfo);
Smarpod_Status Smarpod_GetModels(unsigned int *modelList, unsigned int *ioListSize);
Smarpod_Status Smarpod_GetModelName(unsigned int model, char const **name);
Smarpod_Status Smarpod_Open(unsigned int *smarpodId, unsigned int model, char const *locator, char const *options);
Smarpod_Status Smarpod_Close(unsigned int smarpodId);
Smarpod_Status Smarpod_FindSystems(char const *options, char *systems, unsigned int *ioBufferSize);
Smarpod_Status Smarpod_GetSystemLocator(unsigned int smarpodId, char *locator, unsigned int *ioBufferSize);
Smarpod_Status Smarpod_ConfigureController(unsigned int model, char const *locator, char const *options);
Smarpod_Status Smarpod_Set_ui(unsigned int smarpodId, unsigned int property, unsigned int value);
Smarpod_Status Smarpod_Set_i(unsigned int smarpodId, unsigned int property, int value);
Smarpod_Status Smarpod_Set_d(unsigned int smarpodId, unsigned int property, double value);
Smarpod_Status Smarpod_Get_ui(unsigned int smarpodId, unsigned int property, unsigned int *value);
Smarpod_Status Smarpod_Get_i(unsigned int smarpodId, unsigned int property, int *value);
Smarpod_Status Smarpod_Get_d(unsigned int smarpodId, unsigned int property, double *value);
Smarpod_Status Smarpod_SetSensorMode(unsigned int smarpodId, unsigned int mode);
Smarpod_Status Smarpod_GetSensorMode(unsigned int smarpodId, unsigned int *mode);
Smarpod_Status Smarpod_SetMaxFrequency(unsigned int smarpodId, unsigned int frequency);
Smarpod_Status Smarpod_GetMaxFrequency(unsigned int smarpodId, unsigned int *frequency);
Smarpod_Status Smarpod_SetSpeed(unsigned int smarpodId, int speedControl, double speed);
Smarpod_Status Smarpod_GetSpeed(unsigned int smarpodId, int *speedControl, double *speed);
Smarpod_Status Smarpod_SetAcceleration(unsigned int smarpodId, int accelControl, double acceleration);
Smarpod_Status Smarpod_GetAcceleration(unsigned int smarpodId, int *accelControl, double *acceleration);
Smarpod_Status Smarpod_FindReferenceMarks(unsigned int smarpodId);
Smarpod_Status Smarpod_Calibrate(unsigned int smarpodId);
Smarpod_Status Smarpod_IsReferenced(unsigned int smarpodId, int *referenced);
Smarpod_Status Smarpod_SetPivot(unsigned int smarpodId, double const *pivot);
Smarpod_Status Smarpod_GetPivot(unsigned int smarpodId, double *pivot);
Smarpod_Status Smarpod_IsPoseReachable(unsigned int smarpodId, Smarpod_Pose const *pose, int *reachable);
Smarpod_Status Smarpod_GetPose(unsigned int smarpodId, Smarpod_Pose *pose);
Smarpod_Status Smarpod_GetMoveStatus(unsigned int smarpodId, unsigned int *status);
Smarpod_Status Smarpod_Move(unsigned int smarpodId, Smarpod_Pose const *pose, unsigned int holdTime, int waitForCompletion);
Smarpod_Status Smarpod_Stop(unsigned int smarpodId);
Smarpod_Status Smarpod_StopAndHold(unsigned int smarpodId, unsigned int holdTime);
Smarpod_Status Smarpod_Standby(unsigned int smarpodId);
Smarpod_Status Smarpod_SetCoordinateSystem(unsigned int smarpodId, Smarpod_Pose const *csys);
Smarpod_Status Smarpod_GetCoordinateSystem(unsigned int smarpodId, Smarpod_Pose *csys);
Smarpod_Status Smarpod_SetCurrentPoseAsZero(unsigned int smarpodId);
Smarpod_Status Smarpod_SetAxesOrientation(unsigned int smarpodId, double rx, double ry, double rz);
Smarpod_Status Smarpod_GetAxesOrientation(unsigned int smarpodId, double *rx, double *ry, double *rz);
""")
    lib = ffi.dlopen(libName)

class Error(Exception):
    def __init__(self, func, code, arguments):
        self.func = func
        self.code = code
        self.arguments = arguments
    def __str__(self):
        return "{} returned {} with arguments {}".format(self.func, self.code, self.arguments)
class Pose:
    """
    Members:
     - positionX
     - positionY
     - positionZ
     - rotationX
     - rotationY
     - rotationZ

    """
    __slots__ = ['positionX', 'positionY', 'positionZ', 'rotationX', 'rotationY', 'rotationZ', 'cHandle']
    def __init__(self, positionX, positionY, positionZ, rotationX, rotationY, rotationZ, cHandle = None):
        if positionX is not None:
            self.positionX = positionX
        if positionY is not None:
            self.positionY = positionY
        if positionZ is not None:
            self.positionZ = positionZ
        if rotationX is not None:
            self.rotationX = rotationX
        if rotationY is not None:
            self.rotationY = rotationY
        if rotationZ is not None:
            self.rotationZ = rotationZ
        self.cHandle = cHandle
    def __getattr__(self, attr):
        if self.cHandle is not None:
            value = getattr(self.cHandle, attr)
            retValue = value
            setattr(self, attr, retValue)
            return retValue
        else:
            raise AttributeError(f"Pose has no attribute: {attr}")
    def asFFI(self):
        return ffi.new(_ffiApiGenCachedTypes[0], {'positionX': self.positionX, 'positionY': self.positionY, 'positionZ': self.positionZ, 'rotationX': self.rotationX, 'rotationY': self.rotationY, 'rotationZ': self.rotationZ})
def GetDLLVersion():
    """
    Returns the library version.
    
    Return value(s):
     - major: Major version.
     - minor: Minor version.
     - update: Update version.
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[1])
    local_1 = ffi.new(_ffiApiGenCachedTypes[1])
    local_2 = ffi.new(_ffiApiGenCachedTypes[1])
    local_3 = lib.Smarpod_GetDLLVersion(local_0, local_1, local_2)
    if local_3 != ErrorCode.OK.value:
        raise Error("GetDLLVersion", local_3, {})
    return local_0[0], local_1[0], local_2[0]
def GetStatusInfo(status):
    """
    Returns a string representation for a status code.
    
    Parameters:
     - status: The status code.
    
    Return value(s):
     - statusInfo: The returned status string.
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[2])
    local_1 = lib.Smarpod_GetStatusInfo(status, local_0)
    if local_1 != ErrorCode.OK.value:
        raise Error("GetStatusInfo", local_1, {"status": status})
    return ffi.string(local_0[0]).decode()
def GetModels(ioListSize = 1024):
    """
    Returns list of supported model codes.
    
    Parameters:
     - ioListSize = 1024: Pass the size of the provided buffer in here, on
    return, it contains the number of characters returned in modelList,
     or the required size, if the supplied buffer was too small.
    
    Return value(s):
     - modelList: The buffer the results are written into. the found items
    are separated by a newline character.
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[3], ioListSize)
    local_1 = ffi.new(_ffiApiGenCachedTypes[1], ioListSize)
    local_2 = lib.Smarpod_GetModels(local_0, local_1)
    if local_2 != ErrorCode.OK.value:
        raise Error("GetModels", local_2, {})
    return ffi.unpack(local_0, local_1[0])
def GetModelName(model):
    """
    Returns the name for a model code.
    
    Parameters:
     - model: The model code.
    
    Return value(s):
     - name: The returned model name.
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[2])
    local_1 = lib.Smarpod_GetModelName(model, local_0)
    if local_1 != ErrorCode.OK.value:
        raise Error("GetModelName", local_1, {"model": model})
    return ffi.string(local_0[0]).decode()
def Open(model, locator, options = ""):
    """
    Opens a SmarPod and returns a handle to the device.

    Parameters:
     - model: The SmarPod model code.
     - locator: The controller locator.
     - options = "": Options (reserved).

    Return value(s):
     - smarpodId: The device handle.
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[1])
    local_1 = lib.Smarpod_Open(local_0, model, locator.encode(), options.encode())
    if local_1 != ErrorCode.OK.value:
        raise Error("Open", local_1, {"model": model, "locator": locator, "options": options})
    return local_0[0]
def Close(smarpodId):
    """
    Closes the SmarPod session.
    
    Parameters:
     - smarpodId: The device handle.
    """
    local_0 = lib.Smarpod_Close(smarpodId)
    if local_0 != ErrorCode.OK.value:
        raise Error("Close", local_0, {"smarpodId": smarpodId})
def FindSystems(options = "", ioBufferSize = 256):
    """
    Searches for controllers.
    
    Parameters:
     - options = "": Reserved for now.
     - ioBufferSize = 256: Pass the size of the provided buffer in here, on
     return, it contains the number of characters returned in systems, or
    the required size, if the supplied buffer was too small.
    
    Return value(s):
     - systems: The buffer for writing the result into. the found items are
     separated by a newline character.
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[4], ioBufferSize)
    local_1 = ffi.new(_ffiApiGenCachedTypes[1], ioBufferSize)
    local_2 = lib.Smarpod_FindSystems(options.encode(), local_0, local_1)
    if local_2 != ErrorCode.OK.value:
        raise Error("FindSystems", local_2, {"options": options})
    return ffi.unpack(local_0, local_1[0]).decode()
def GetSystemLocator(smarpodId, ioBufferSize = 1024):
    """
    Returns the locator of the controller.

    Parameters:
     - smarpodId: SmarPod device handle.
     - ioBufferSize = 1024: Pass the size of the provided buffer in here,
    on return, it contains the number of characters returned in
    locator, or the required size, if the supplied buffer was too
    small.
    
    Return value(s):
     - locator: The buffer for writing the result into.
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[4], ioBufferSize)
    local_1 = ffi.new(_ffiApiGenCachedTypes[1], ioBufferSize)
    local_2 = lib.Smarpod_GetSystemLocator(smarpodId, local_0, local_1)
    if local_2 != ErrorCode.OK.value:
        raise Error("GetSystemLocator", local_2, {"smarpodId": smarpodId})
    return ffi.unpack(local_0, local_1[0]).decode()
def ConfigureController(model, locator, options = ""):
    """
    Configures the MCS controller for the selected SmarPod model.
    
    Parameters:
     - model: The SmarPod model code.
     - locator: The controller locator.
     - options = "": Options (reserved).
    """
    local_0 = lib.Smarpod_ConfigureController(model, locator.encode(), options.encode())
    if local_0 != ErrorCode.OK.value:
        raise Error("ConfigureController", local_0, {"model": model, "locator": locator, "options": options})
def Set_ui(smarpodId, property, value):
    """
    Sets an unsigned integer property.
    
    Parameters:
     - smarpodId: The device handle.
     - property: The property key.
     - value: The property value.
    """
    local_0 = lib.Smarpod_Set_ui(smarpodId, property, value)
    if local_0 != ErrorCode.OK.value:
        raise Error("Set_ui", local_0, {"smarpodId": smarpodId, "property": property, "value": value})
def Set_i(smarpodId, property, value):
    """
    Sets a signed integer property.
    
    Parameters:
     - smarpodId: The device handle.
     - property: The property key.
     - value: The property value.
    """
    local_0 = lib.Smarpod_Set_i(smarpodId, property, value)
    if local_0 != ErrorCode.OK.value:
        raise Error("Set_i", local_0, {"smarpodId": smarpodId, "property": property, "value": value})
def Set_d(smarpodId, property, value):
    """
    Sets a double precision floating point property.
    
    Parameters:
     - smarpodId: The device handle.
     - property: The property key.
     - value: The property value.
    """
    local_0 = lib.Smarpod_Set_d(smarpodId, property, value)
    if local_0 != ErrorCode.OK.value:
        raise Error("Set_d", local_0, {"smarpodId": smarpodId, "property": property, "value": value})
def Get_ui(smarpodId, property):
    """
    Returns the value of an unsigned integer property.
    
    Parameters:
     - smarpodId: The device handle.
     - property: The property key.
    
    Return value(s):
     - value: The property value.
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[1])
    local_1 = lib.Smarpod_Get_ui(smarpodId, property, local_0)
    if local_1 != ErrorCode.OK.value:
        raise Error("Get_ui", local_1, {"smarpodId": smarpodId, "property": property})
    return local_0[0]
def Get_i(smarpodId, property):
    """
    Returns the value of a signed integer property.
    
    Parameters:
     - smarpodId: The device handle.
     - property: The property key.
    
    Return value(s):
     - value: The property value.
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[5])
    local_1 = lib.Smarpod_Get_i(smarpodId, property, local_0)
    if local_1 != ErrorCode.OK.value:
        raise Error("Get_i", local_1, {"smarpodId": smarpodId, "property": property})
    return local_0[0]
def Get_d(smarpodId, property):
    """
    Returns the value of double precision floating point property.
    
    Parameters:
     - smarpodId: The device handle.
     - property: The property key.
    
    Return value(s):
     - value: The property value.
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[6])
    local_1 = lib.Smarpod_Get_d(smarpodId, property, local_0)
    if local_1 != ErrorCode.OK.value:
        raise Error("Get_d", local_1, {"smarpodId": smarpodId, "property": property})
    return local_0[0]
def SetSensorMode(smarpodId, mode):
    """
    Sets the sensor power mode.
    
    Parameters:
     - smarpodId: The device handle.
     - mode: The sensor power mode.
    """
    local_0 = lib.Smarpod_SetSensorMode(smarpodId, mode)
    if local_0 != ErrorCode.OK.value:
        raise Error("SetSensorMode", local_0, {"smarpodId": smarpodId, "mode": mode})
def GetSensorMode(smarpodId):
    """
    Returns the sensor power mode.
    
    Parameters:
     - smarpodId: The device handle.
    
    Return value(s):
     - mode: The sensor power mode.
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[1])
    local_1 = lib.Smarpod_GetSensorMode(smarpodId, local_0)
    if local_1 != ErrorCode.OK.value:
        raise Error("GetSensorMode", local_1, {"smarpodId": smarpodId})
    return local_0[0]
def SetMaxFrequency(smarpodId, frequency):
    """
    Sets maximum closed-loop frequency.
    
    Parameters:
     - smarpodId: The device handle.
     - frequency: The frequency in Hz.
    """
    local_0 = lib.Smarpod_SetMaxFrequency(smarpodId, frequency)
    if local_0 != ErrorCode.OK.value:
        raise Error("SetMaxFrequency", local_0, {"smarpodId": smarpodId, "frequency": frequency})
def GetMaxFrequency(smarpodId):
    """
    Returns the maximum closed-loop frequency.
    
    Parameters:
     - smarpodId: The device handle.
    
    Return value(s):
     - frequency: The frequency in Hz.
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[1])
    local_1 = lib.Smarpod_GetMaxFrequency(smarpodId, local_0)
    if local_1 != ErrorCode.OK.value:
        raise Error("GetMaxFrequency", local_1, {"smarpodId": smarpodId})
    return local_0[0]
def SetSpeed(smarpodId, speedControl, speed):
    """
    Sets the movement speed.
    
    Parameters:
     - smarpodId: The device handle.
     - speedControl: If TRUE (1), speed control is enabled, if FALSE (0),
    it is disabled.
     - speed: The speed in m/s.
    """
    local_0 = lib.Smarpod_SetSpeed(smarpodId, speedControl, speed)
    if local_0 != ErrorCode.OK.value:
        raise Error("SetSpeed", local_0, {"smarpodId": smarpodId, "speedControl": speedControl, "speed": speed})
def GetSpeed(smarpodId):
    """
    Returns the movement speed.
    
    Parameters:
     - smarpodId: The device handle.
    
    Return value(s):
     - speedControl: If TRUE (1), speed control is enabled, if FALSE (0),
    it is disabled.
     - speed: The speed in m/s.
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[5])
    local_1 = ffi.new(_ffiApiGenCachedTypes[6])
    local_2 = lib.Smarpod_GetSpeed(smarpodId, local_0, local_1)
    if local_2 != ErrorCode.OK.value:
        raise Error("GetSpeed", local_2, {"smarpodId": smarpodId})
    return local_0[0], local_1[0]
def SetAcceleration(smarpodId, accelControl, acceleration):
    """
    Sets the movement acceleration.
    
    Parameters:
     - smarpodId: The device handle.
     - accelControl: If TRUE (1), acceleration control is enabled, if FALSE
     (0), it is disabled.
     - acceleration: The acceleration in m/s^2.
    """
    local_0 = lib.Smarpod_SetAcceleration(smarpodId, accelControl, acceleration)
    if local_0 != ErrorCode.OK.value:
        raise Error("SetAcceleration", local_0, {"smarpodId": smarpodId, "accelControl": accelControl, "acceleration": acceleration})
def GetAcceleration(smarpodId):
    """
    Returns the movement acceleration.
    
    Parameters:
     - smarpodId: The device handle.
    
    Return value(s):
     - accelControl: If TRUE (1), acceleration control is enabled, if FALSE
     (0), it is disabled.
     - acceleration: The acceleration in m/s^2.
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[5])
    local_1 = ffi.new(_ffiApiGenCachedTypes[6])
    local_2 = lib.Smarpod_GetAcceleration(smarpodId, local_0, local_1)
    if local_2 != ErrorCode.OK.value:
        raise Error("GetAcceleration", local_2, {"smarpodId": smarpodId})
    return local_0[0], local_1[0]
def FindReferenceMarks(smarpodId):
    """
    Search for positioner reference marks. If successful, the SmarPod will
    be referenced afterwards.

    Parameters:
     - smarpodId: The device handle.
    """
    local_0 = lib.Smarpod_FindReferenceMarks(smarpodId)
    if local_0 != ErrorCode.OK.value:
        raise Error("FindReferenceMarks", local_0, {"smarpodId": smarpodId})
def Calibrate(smarpodId):
    """
    Calibrate the SmarPod positioners.
    
    Parameters:
     - smarpodId: The device handle.
    """
    local_0 = lib.Smarpod_Calibrate(smarpodId)
    if local_0 != ErrorCode.OK.value:
        raise Error("Calibrate", local_0, {"smarpodId": smarpodId})
def IsReferenced(smarpodId):
    """
    Returns referenced status.
    
    Parameters:
     - smarpodId: The device handle.
    
    Return value(s):
     - referenced: The referenced state: FALSE (0) (not referenced) or TRUE
     (1) (referenced).
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[5])
    local_1 = lib.Smarpod_IsReferenced(smarpodId, local_0)
    if local_1 != ErrorCode.OK.value:
        raise Error("IsReferenced", local_1, {"smarpodId": smarpodId})
    return local_0[0]
def SetPivot(smarpodId, pivot):
    """
    Set the pivot point.
    
    Parameters:
     - smarpodId: The device handle.
     - pivot: An array of size three with the pivot point coodinates X,Y,Z.
    
    """
    local_0 = lib.Smarpod_SetPivot(smarpodId, pivot)
    if local_0 != ErrorCode.OK.value:
        raise Error("SetPivot", local_0, {"smarpodId": smarpodId, "pivot": pivot})
def GetPivot(smarpodId):
    """
    Returns the pivot point.
    
    Parameters:
     - smarpodId: The device handle.
    
    Return value(s):
     - pivot: An array of size three to write the pivot point coodinates
    X,Y,Z to.
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[7], 3)
    local_1 = lib.Smarpod_GetPivot(smarpodId, local_0)
    if local_1 != ErrorCode.OK.value:
        raise Error("GetPivot", local_1, {"smarpodId": smarpodId})
    return ffi.unpack(local_0, 3)
def IsPoseReachable(smarpodId, pose):
    """
    Check if the specified pose is reachable.
    
    Parameters:
     - smarpodId: The device handle.
     - pose: The pose to test.
    
    Return value(s):
     - reachable: TRUE (1) if pose is reachable, else FALSE (0).
    """
    local_0 = pose.asFFI()
    local_1 = ffi.new(_ffiApiGenCachedTypes[5])
    local_2 = lib.Smarpod_IsPoseReachable(smarpodId, local_0, local_1)
    if local_2 != ErrorCode.OK.value:
        raise Error("IsPoseReachable", local_2, {"smarpodId": smarpodId, "pose": pose})
    return local_1[0]
def GetPose(smarpodId):
    """
    Returns the current pose.
    
    Parameters:
     - smarpodId: The device handle.
    
    Return value(s):
     - pose: The current pose.
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[0])
    local_1 = lib.Smarpod_GetPose(smarpodId, local_0)
    if local_1 != ErrorCode.OK.value:
        raise Error("GetPose", local_1, {"smarpodId": smarpodId})
    return Pose(None, None, None, None, None, None, local_0)
def GetMoveStatus(smarpodId):
    """
    Returns the current move status.

    Parameters:
     - smarpodId: The device handle.
    
    Return value(s):
     - status: The current move status.
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[1])
    local_1 = lib.Smarpod_GetMoveStatus(smarpodId, local_0)
    if local_1 != ErrorCode.OK.value:
        raise Error("GetMoveStatus", local_1, {"smarpodId": smarpodId})
    return local_0[0]
def Move(smarpodId, pose, holdTime, waitForCompletion):
    """
    Move to a pose.
    
    Parameters:
     - smarpodId: The device handle.
     - pose: The target pose.
     - holdTime: The time to hold the target pose after move in
    milliseconds.
     - waitForCompletion: If TRUE (1), wait for termination of movement,
    otherwise return immediately.
    """
    local_0 = pose.asFFI()
    local_1 = lib.Smarpod_Move(smarpodId, local_0, holdTime, waitForCompletion)
    if local_1 != ErrorCode.OK.value:
        raise Error("Move", local_1, {"smarpodId": smarpodId, "pose": pose, "holdTime": holdTime, "waitForCompletion": waitForCompletion})
def Stop(smarpodId):
    """
    Stop any motion.

    Parameters:
     - smarpodId: The device handle.
    """
    local_0 = lib.Smarpod_Stop(smarpodId)
    if local_0 != ErrorCode.OK.value:
        raise Error("Stop", local_0, {"smarpodId": smarpodId})
def StopAndHold(smarpodId, holdTime):
    """
    Stop any motion and actively hold current pose.
    
    Parameters:
     - smarpodId: The device handle.
     - holdTime
    """
    local_0 = lib.Smarpod_StopAndHold(smarpodId, holdTime)
    if local_0 != ErrorCode.OK.value:
        raise Error("StopAndHold", local_0, {"smarpodId": smarpodId, "holdTime": holdTime})
def Standby(smarpodId):
    """
    Put all positioners into standby mode.
    
    Parameters:
     - smarpodId: The device handle.
    """
    local_0 = lib.Smarpod_Standby(smarpodId)
    if local_0 != ErrorCode.OK.value:
        raise Error("Standby", local_0, {"smarpodId": smarpodId})
def SetCoordinateSystem(smarpodId, csys):
    """
    Set the coordinate system (only with zero axes orientation).
    
    Parameters:
     - smarpodId: The device handle.
     - csys: The new coordinate system.
    """
    local_0 = csys.asFFI()
    local_1 = lib.Smarpod_SetCoordinateSystem(smarpodId, local_0)
    if local_1 != ErrorCode.OK.value:
        raise Error("SetCoordinateSystem", local_1, {"smarpodId": smarpodId, "csys": csys})
def GetCoordinateSystem(smarpodId):
    """
    Returns the coordinate system.
    
    Parameters:
     - smarpodId: The device handle.
    
    Return value(s):
     - csys: The new coordinate system.
    """
    local_0 = ffi.new(_ffiApiGenCachedTypes[0])
    local_1 = lib.Smarpod_GetCoordinateSystem(smarpodId, local_0)
    if local_1 != ErrorCode.OK.value:
        raise Error("GetCoordinateSystem", local_1, {"smarpodId": smarpodId})
    return Pose(None, None, None, None, None, None, local_0)
def SetCurrentPoseAsZero(smarpodId):
    """
    Set the current pose as coordinate system zero pose (only with zero
    axes orientation).
    
    Parameters:
     - smarpodId: The device handle.
    """
    local_0 = lib.Smarpod_SetCurrentPoseAsZero(smarpodId)
    if local_0 != ErrorCode.OK.value:
        raise Error("SetCurrentPoseAsZero", local_0, {"smarpodId": smarpodId})
def SetAxesOrientation(smarpodId, rx, ry, rz):
    """
    Set the axes orientation (only with zero coordinate system).
    
    Parameters:
     - smarpodId: The device handle.
     - rx
     - ry
     - rz
    """
    local_0 = lib.Smarpod_SetAxesOrientation(smarpodId, rx, ry, rz)
    if local_0 != ErrorCode.OK.value:
        raise Error("SetAxesOrientation", local_0, {"smarpodId": smarpodId, "rx": rx, "ry": ry, "rz": rz})
def GetAxesOrientation(smarpodId, rx, ry, rz):
    """
    Returns the axes orientation.
    
    Parameters:
     - smarpodId: The device handle.
     - rx
     - ry
     - rz
    """
    local_0 = lib.Smarpod_GetAxesOrientation(smarpodId, rx, ry, rz)
    if local_0 != ErrorCode.OK.value:
        raise Error("GetAxesOrientation", local_0, {"smarpodId": smarpodId, "rx": rx, "ry": ry, "rz": rz})
class ApiVersion(enum.IntEnum):
    MAJOR  = 0x1
    MINOR  = 0xb
    UPDATE = 0x5
class ErrorCode(enum.IntEnum):
    OK                     = 0x000
    OTHER                  = 0x001
    SYSTEM_NOT_INITIALIZED = 0x002
    NO_SYSTEMS_FOUND       = 0x003
    INVALID_PARAMETER      = 0x004
    COMMUNICATION          = 0x005
    UNKNOWN_PROPERTY       = 0x006
    RESOURCE_TOO_OLD       = 0x007
    FEATURE_UNAVAILABLE    = 0x008
    INVALID_SYSTEM_LOCATOR = 0x009
    QUERYBUFFER_SIZE       = 0x00a
    COMMUNICATION_TIMEOUT  = 0x00b
    DRIVER                 = 0x00c
    STATUS_CODE_UNKNOWN    = 0x1f4
    INVALID_ID             = 0x1f5
    INITIALIZED            = 0x1f6
    HARDWARE_MODEL_UNKNOWN = 0x1f7
    WRONG_COMM_MODE        = 0x1f8
    NOT_INITIALIZED        = 0x1f9
    INVALID_SYSTEM_ID      = 0x1fa
    NOT_ENOUGH_CHANNELS    = 0x1fb
    INVALID_CHANNEL        = 0x1fc
    CHANNEL_USED           = 0x1fd
    SENSORS_DISABLED       = 0x1fe
    WRONG_SENSOR_TYPE      = 0x1ff
    SYSTEM_CONFIGURATION   = 0x200
    SENSOR_NOT_FOUND       = 0x201
    STOPPED                = 0x202
    BUSY                   = 0x203
    NOT_REFERENCED         = 0x226
    POSE_UNREACHABLE       = 0x227
    COMMAND_OVERRIDDEN     = 0x228
    ENDSTOP_REACHED        = 0x229
    NOT_STOPPED            = 0x22a
    COULD_NOT_REFERENCE    = 0x22b
    COULD_NOT_CALIBRATE    = 0x22c
class Global(enum.IntEnum):
    DEFAULT           = 0x0000
    FALSE             = 0x0000
    TRUE              = 0x0001
    HOLDTIME_INFINITE = 0xea60
DEFAULT = Global.DEFAULT
FALSE = Global.FALSE
TRUE = Global.TRUE
HOLDTIME_INFINITE = Global.HOLDTIME_INFINITE
class Property(enum.IntEnum):
    FREF_METHOD            = 0x3e8
    FREF_ZDIRECTION        = 0x3ea
    FREF_XDIRECTION        = 0x3eb
    FREF_YDIRECTION        = 0x3ec
    PIVOT_MODE             = 0x3f2
    FREF_AND_CAL_FREQUENCY = 0x3fc
    POSITIONERS_MIN_SPEED  = 0x44c
class Axis(enum.IntEnum):
    X = 0x1
    Y = 0x2
    Z = 0x4
class Direction(enum.IntEnum):
    POSITIVE = 0x0100
    NEGATIVE = 0x0200
    REVERSE  = 0x1000
class PivotMode(enum.IntEnum):
    RELATIVE = 0x0
    FIXED    = 0x1
class FrefMethod(enum.IntEnum):
    SEQUENTIAL = 0x1
    ZSAFE      = 0x2
    XYSAFE     = 0x3
class SensorPowerMode(enum.IntEnum):
    DISABLED  = 0x0
    ENABLED   = 0x1
    POWERSAVE = 0x2
class MoveStatus(enum.IntEnum):
    STOPPED     = 0x0
    HOLDING     = 0x1
    MOVING      = 0x2
    CALIBRATING = 0x3
    REFERENCING = 0x4
    STANDBY     = 0x5
import platform
__initBindings("SmarPod.dll" if platform.system() == "Windows" else ("lib" + "SmarPod".lower() + ".so"))
def __initFfiApiGenCachedTypes():
    global _ffiApiGenCachedTypes
    _ffiApiGenCachedTypes = [
        ffi.typeof("Smarpod_Pose *"),
        ffi.typeof("unsigned int *"),
        ffi.typeof("char const **"),
        ffi.typeof("unsigned int []"),
        ffi.typeof("char []"),
        ffi.typeof("int *"),
        ffi.typeof("double *"),
        ffi.typeof("double []")]
__initFfiApiGenCachedTypes()
__all__ = ["api_version", "apigen_version", "Error", "Pose", "GetDLLVersion", "GetStatusInfo", "GetModels", "GetModelName", "Open", "Close", "FindSystems", "GetSystemLocator", "ConfigureController", "Set_ui", "Set_i", "Set_d", "Get_ui", "Get_i", "Get_d", "SetSensorMode", "GetSensorMode", "SetMaxFrequency", "GetMaxFrequency", "SetSpeed", "GetSpeed", "SetAcceleration", "GetAcceleration", "FindReferenceMarks", "Calibrate", "IsReferenced", "SetPivot", "GetPivot", "IsPoseReachable", "GetPose", "GetMoveStatus", "Move", "Stop", "StopAndHold", "Standby", "SetCoordinateSystem", "GetCoordinateSystem", "SetCurrentPoseAsZero", "SetAxesOrientation", "GetAxesOrientation", "ApiVersion", "ErrorCode", "DEFAULT", "FALSE", "TRUE", "HOLDTIME_INFINITE", "Property", "Axis", "Direction", "PivotMode", "FrefMethod", "SensorPowerMode", "MoveStatus"]
